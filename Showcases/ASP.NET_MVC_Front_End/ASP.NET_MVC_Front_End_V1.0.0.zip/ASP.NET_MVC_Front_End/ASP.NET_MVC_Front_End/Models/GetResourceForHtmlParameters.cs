﻿
namespace MvcSample.Models
{
    public class GetResourceForHtmlParameters
    {
        public string DocumentPath { get; set; }
        public string ResourceName { get; set; }
        public int PageNumber { get; set; }
    }
}